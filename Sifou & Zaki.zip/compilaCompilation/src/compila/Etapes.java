﻿package compila;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author LordKarim
 */
public class Etapes {
    File file ;
    ArrayList lineList=new ArrayList();
    ArrayList tokensList=new ArrayList();
    ArrayList stlineList=new ArrayList();
    String code;
    
    Etapes(){
        
    }
    public String charge(){
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Compila file", "compila");
	 
        fileChooser.setDialogTitle("Choose a file");
        fileChooser.setFileFilter(filter);
        if(fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
            //get the file
            file = fileChooser.getSelectedFile();
	}
        
        try {
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuffer stringBuffer = new StringBuffer();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuffer.append(line);
                stringBuffer.append("\n");
                lineList.add(line);//list of lines
            }
            fileReader.close();
            code=stringBuffer.toString();//the code
        } catch (IOException e) {
            e.printStackTrace();
        }
        return code;
    }    
    
    public int Identificateur(String ident){
        int bool=1 ;
	
	switch(ident) {
	case "Snl_Start" : 
		bool =0; 
		break;
	case "Snl_Int" :
		bool =0; 
		break;
	case "Snl_Real" : 
		bool =0; 
		break;
	case "Snl_Put" : 
		bool =0; 
		break;
	case "SnlSt" : 
		bool =0; 
		break;
	case "Set" : 
		bool =0; 
		break;
	case "Get" : 
		bool =0; 
		break;
	case "If" : 
		bool =0; 
		break;
	case "Else" : 
		bool =0; 
		break;
	case "Start" : 
		bool =0; 
		break;
	case "Finish" : 
		bool =0; 
		break;
		
	}
		
	if((Character.isLetter(ident.charAt(0))) || (Character.isUpperCase(ident.charAt(0)))){ 
	
            for (int i =1; (i< ident.length()) && (bool==1) ; i++){
                
                if((Character.isDigit(ident.charAt(i))) || (Character.isLetter(ident.charAt(i))) ||Character.isUpperCase(ident.charAt(i))) {
                    bool=1 ;
	        }
                
                else if(ident.charAt(i) == '_'){
                    if((Character.isDigit(ident.charAt(i+1))) || (Character.isLetter(ident.charAt(i+1))) || Character.isUpperCase(ident.charAt(i+1))) {
		         bool=1;
                    }
                }
                
	        else bool = 0;
		                    
            }
            
        }
        else bool = 0;
        
        //if(bool==1)System.out.println("valide");
        //else if(bool==0)System.out.println("non valide");
        
        return bool;
    }

    public String lexical(){
        String lesTokens="";
        StringTokenizer st = new StringTokenizer(code);
        
        while (st.hasMoreTokens())
            tokensList.add(st.nextToken());
        for(int i=0 ;i<tokensList.size() ; i++){
            
            if(tokensList.get(i).equals("Start_Program") || tokensList.get(i).equals("start_Program")) 
                lesTokens=tokensList.get(i)+" : Mot résevé pour debut de program\n";
            else if(tokensList.get(i).equals("End_Program")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot réservé pour fin de program\n";
            else if(tokensList.get(i).equals("Int_Number")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour declaration d'un entier\n";
            else if(tokensList.get(i).equals(",")) 
                lesTokens=lesTokens+tokensList.get(i)+" : une virgule\n";
            else if(tokensList.get(i).equals("Real_Number")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour declaration d'un real\n";
            else if(tokensList.get(i).equals(";;")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour fin de ligne\n";
            else if(tokensList.get(i).equals("Give")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour initialisation\n";
            else if(tokensList.get(i).equals("If")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour une condition\n";
            else if(tokensList.get(i).equals("Else")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour une 2eme codition\n";
            else if(tokensList.get(i).equals("<")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Operatuer de comparaison\n";
            else if(tokensList.get(i).equals(">")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Operatuer de comparaison\n";
            else if(tokensList.get(i).equals("--")) 
                lesTokens=lesTokens+tokensList.get(i)+" : debut ou fin de codition\n";
            else if(tokensList.get(i).equals("Start")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot réservé pour un debut de block\n";
            else if(tokensList.get(i).equals("Finish")) 
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour un fin de block\n";
            else if(tokensList.get(i).equals("ShowMes"))
                lesTokens=lesTokens+tokensList.get(i)+" : Mot réservé pour affichage\n";
            else if(tokensList.get(i).equals("//."))
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour commentaire\n";
            else if(tokensList.get(i).equals("Affect"))
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour affectation\n";
            else if(estNum((String)tokensList.get(i))==true)
                lesTokens=lesTokens+tokensList.get(i)+" : Mot resevé pour un nombre\n";
            else if(tokensList.get(i).equals("\""))
                lesTokens=lesTokens+tokensList.get(i)+" : debut ou fin d'un message\n";
            else if(Identificateur((String)tokensList.get(i))==1)
                lesTokens=lesTokens+tokensList.get(i)+" : identificateur\n";
        }
        return lesTokens;
    }
    
    public String syntaxique(){
         String lesLignes="";
        StringTokenizer stemp;
        int bool=0;
        boolean enter=false;
        //----------------------------------------------------start du program
        if(lineList.get(0).equals("Start_Program") || lineList.get(0).equals("Start_Program")) {
            lesLignes=lesLignes+lineList.get(0)+" : valid starting\n";
            enter=true;
        } else lesLignes=lesLignes+"starting non valide\n";
        //----------------------------------------------------------------------
        
            for(int i=1 ;i<lineList.size() && enter==true;i++){
                //stlineList.clear();
                stemp = new StringTokenizer((String) lineList.get(i));
            
                while (stemp.hasMoreTokens())
                    stlineList.add(stemp.nextToken());
                
             //--------------------------------------------------   
                if(stlineList.get(0).equals("Int_Number") || stlineList.get(0).equals("Real_Number")){
                    for(int j=1 ;j<stlineList.size() ;j++){
                        if(stlineList.get(j).equals(";;")){
                            //bool=1;
                            break;
                        }
                        else if(Identificateur((String) stlineList.get(j))==1){
                             bool=1;
                        }
                        else if(stlineList.get(j).equals(","));
                        else {bool=0;break;}
                        
                        if(!stlineList.get(stlineList.size()-1).equals(";;"))bool=0;
                        
                    }
                    if(stlineList.get(1).equals(","))bool=0;
                    if(stlineList.get(1).equals(":"))bool=1;

                    
                    if(bool==1)lesLignes=lesLignes+lineList.get(i)+" : valide";
                    else if(bool==0) lesLignes=lesLignes+"non valide verifiez votre syntaxe ou Id non valide ou il manque des espaces";
                }
             //---------------------------------------------------
                if(stlineList.get(0).equals("Affect")){
                    if(Identificateur((String) stlineList.get(1))==1){
                        if(stlineList.get(2).equals("to")){
                            if(Identificateur((String) stlineList.get(3))==1){
                                if(stlineList.get(4).equals(";;")){
                                    lesLignes=lesLignes+lineList.get(i)+" : valide";
                                }else lesLignes=lesLignes+" : il manque une ;;";
                            }else lesLignes=lesLignes+" : 2eme id non valide"; 
                        }else lesLignes=lesLignes+" : il manque \":\" ";
                    }else lesLignes=lesLignes+" : 1er id non valide";  
                }
             //----------------------------------------------------- 
                if(stlineList.get(0).equals("ShowMes")){
                    
                    if(stlineList.get(1).equals(":")){
                        if(stlineList.get(stlineList.size()-2).equals("\"")){
                            
                            if(stlineList.get(stlineList.size()-1).equals(";;")){
                                lesLignes=lesLignes+lineList.get(i)+" : valide";
                            }else lesLignes=lesLignes+" : il manque une ;;";
                        }else lesLignes=lesLignes+" : il manque  une \"";
                    }
                    
                    else if (Identificateur((String) stlineList.get(1))==1){
                        if(stlineList.get(stlineList.size()-1).equals(";;")){
                                lesLignes=lesLignes+lineList.get(i)+" : valide";
                            }else lesLignes=lesLignes+" : il manque une ;;";
                    }
                    else lesLignes=lesLignes+"non valide verifiez votre syntaxe";
                }
                
                
                if(stlineList.get(0).equals("ShowVal")){
                    if(stlineList.get(1).equals(":")){
                        if(stlineList.get(stlineList.size()-1).equals(";;")){
                            lesLignes=lesLignes+lineList.get(i)+" : valide";
                        }else lesLignes=lesLignes+" : il manque une ;;";
                    }
                }
              //----------------------------------------------------------- 
                if(stlineList.get(0).equals("//.")){
                    bool=1;
                    lesLignes=lesLignes+lineList.get(i)+" : valide";
                }
              //---------------------------------------------------------if
                if(stlineList.get(0).equals("If") || stlineList.get(0).equals("if")){
                    if(stlineList.get(1).equals("--")){
                        if(Identificateur((String) stlineList.get(2))==1){
                           // if(stlineList.get(3).equals(">") || stlineList.get(3).equals("<")){
                                if(Identificateur((String) stlineList.get(4))==1){
                                    if(stlineList.get(5).equals("--")){
                                    }
                                    else lesLignes=lesLignes+"il manque le 2eme --\n";
                                }
                                else lesLignes=lesLignes+"il manque le 2eme id ou il est non valide\n";
                           // }
                            //else syntaxprinter=syntaxprinter+"no <>\n";
                        }
                        else lesLignes=lesLignes+"il manque le 1er id ou il est non valide\n";
                    }  
                    else lesLignes=lesLignes+"il manque le 1er --\n";  
                    
                    if(bool==1)lesLignes=lesLignes+lineList.get(i)+" : valide";
                    else if(bool==0) lesLignes=lesLignes+"non valide verifiez votre syntaxe";
                }
               //-------------------------------------------------------Set
                if(stlineList.get(0).equals("Give")){
                    if(Identificateur((String) stlineList.get(1))==1){
                        if(stlineList.get(2).equals(":")){
                            if(estNum((String) stlineList.get(3))==true){
                                if(stlineList.get(4).equals(";;")){
                                    lesLignes=lesLignes+lineList.get(i)+" : valide";
                                }else bool=0;  
                            }    
                            else lesLignes=lesLignes+" : il manque une ;;";  
                        }else lesLignes=lesLignes+" : il manque une le : ";  
                    }else lesLignes=lesLignes+" : id non valide";  
                }
               //------------------------------------------------------- Else Start Finish
                if(stlineList.get(0).equals("Else") || stlineList.get(0).equals("Start") || stlineList.get(0).equals("Finish")){
                    bool=1;
                    lesLignes=lesLignes+lineList.get(i)+" : valide";
                }
                //-------------------------------------------------------------videz la list des linetokens
                lesLignes=lesLignes+"\n";
                stlineList.clear();
            }
            if(VerifBlock(code)==false)lesLignes=lesLignes+" il manque une 'Start' ou 'Finish'" ;
            //--------------------------------------------------closing
            if(lineList.get(lineList.size()-1).equals("End_Program")) {
            lesLignes=lesLignes+lineList.get(lineList.size()-1)+" : valid closnging\n";
            enter=true;
        } else lesLignes=lesLignes+"closing non valide\n";
        stlineList.clear();             
        return lesLignes;
    }
    
    public String semantique(){
        String trad="";
        StringTokenizer stemp; 
        ArrayList srLineToJava=new ArrayList();
        
        for(int i=1; i<lineList.size() ;i++){
            stemp = new StringTokenizer((String) lineList.get(i));
            
            while (stemp.hasMoreTokens())
                srLineToJava.add(stemp.nextToken());   
            
            if(srLineToJava.get(0).equals("Int_Number")){
                trad=trad+"int ";
                for(int j=1 ;j<srLineToJava.size()-1;j++)
                trad=trad+srLineToJava.get(j);
                trad=trad+";\n";
            }
            if(srLineToJava.get(0).equals("Real_Number")){
                trad=trad+"float ";
                for(int j=1 ;j<srLineToJava.size()-1;j++)
                trad=trad+srLineToJava.get(j);
                trad=trad+";\n";
            }
            if(srLineToJava.get(0).equals("Affect"))
                trad=trad+srLineToJava.get(1)+" = "+srLineToJava.get(2)+";"+"\n";
            if(srLineToJava.get(0).equals("If")||srLineToJava.get(0).equals("if"))
                trad=trad+"if("+srLineToJava.get(2)+srLineToJava.get(3)+srLineToJava.get(4)+")\n";
            if(srLineToJava.get(0).equals("Else"))
                trad=trad+"else"+"\n";
            if(srLineToJava.get(0).equals("Start"))
                trad=trad+"{"+"\n";
            if(srLineToJava.get(0).equals("Finish"))
                trad=trad+"}"+"\n";
            if(srLineToJava.get(0).equals("Give"))
                trad=trad+srLineToJava.get(1)+" = "+srLineToJava.get(3)+";"+"\n";
            if(srLineToJava.get(0).equals("ShowMes") || srLineToJava.get(0).equals("ShowVal")){
                if(srLineToJava.get(2).equals("\"")){
                    trad=trad+"System.out.print(\"";
                    for(int j=3 ;j<srLineToJava.size()-2 ;j++)
                        trad=trad+" "+srLineToJava.get(j);
                    trad=trad+"\");";
                }
                else{
                    trad=trad+"System.out.print(";
                    trad=trad+srLineToJava.get(2)+");";
                }
                trad=trad+"\n";
            }
            
            
        srLineToJava.clear();
        }
        return trad;
    }
    public static boolean estNum(String str){  
        try{   
            double d = Double.parseDouble(str);  
        }  
        catch(NumberFormatException nfe){  
            return false;  
        }  
        return true;  
    }
    public boolean VerifBlock(String codeTokens){
        ArrayList blockList=new ArrayList();
        StringTokenizer st=new StringTokenizer(codeTokens);
        int start=0,finish=0;
        while (st.hasMoreTokens())blockList.add(st.nextToken());
        for(int i=0; i<blockList.size() ;i++){
            if(blockList.get(i).equals("Start")) start++;
            if(blockList.get(i).equals("Finish")) finish++;
        }
        if(start==finish) return true;
        else return false;
    }
}
